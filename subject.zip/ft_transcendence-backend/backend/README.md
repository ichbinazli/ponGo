# ft_transcendence Backend

Backend API for ft_transcendence - Pong Game Platform

## Tech Stack

- **Runtime**: Node.js 20+
- **Framework**: Fastify 4.x
- **Database**: SQLite (better-sqlite3)
- **Language**: TypeScript 5.x
- **Authentication**: JWT + OAuth 2.0 + 2FA

## Getting Started

### Prerequisites

- Node.js 20 or higher
- npm or pnpm
- OpenSSL (for generating SSL certificates)

### Installation

1. Clone the repository and navigate to backend:

```bash
cd backend
```

2. Install dependencies:

```bash
npm install
```

3. Copy environment file and configure:

```bash
cp .env.example .env
# Edit .env with your settings
```

4. Generate SSL certificates (for HTTPS):

```bash
cd ..
chmod +x scripts/generate-certs.sh
./scripts/generate-certs.sh
```

5. Start development server:

```bash
npm run dev
```

### Docker

Build and run with Docker Compose:

```bash
# Development
docker-compose up --build

# Production
NODE_ENV=production docker-compose up --build -d
```

## API Endpoints

### Documentation
- `GET /api/docs` - Swagger UI
- `GET /api/docs/openapi.json` - OpenAPI 3.0 specification

### Health Check
- `GET /health` - Server health status
- `GET /api` - API information

### Authentication (`/api/auth`)
- `POST /register` - Register new user
- `POST /login` - Login user
- `POST /logout` - Logout current session
- `POST /logout-all` - Logout all sessions
- `POST /refresh` - Refresh access token
- `GET /me` - Get current user
- `GET /sessions` - List active sessions
- `DELETE /sessions/:id` - Revoke session

### Users (`/api/users`)
- `GET /search` - Search users
- `GET /online` - Get online users
- `GET /:id` - Get user profile
- `GET /:id/matches` - Get user match history
- `GET /:id/stats` - Get user statistics
- `GET /me` - Get own profile
- `PATCH /me` - Update profile
- `POST /me/avatar` - Upload avatar
- `PUT /me/password` - Change password

### Friends (`/api/friends`)
- `GET /` - Get friends list
- `GET /online` - Get online friends
- `GET /requests/incoming` - Incoming requests
- `GET /requests/outgoing` - Outgoing requests
- `POST /request/:id` - Send friend request
- `POST /accept/:id` - Accept request
- `POST /reject/:id` - Reject request
- `DELETE /request/:id` - Cancel request
- `DELETE /:id` - Remove friend
- `GET /status/:id` - Check friendship status
- `POST /block/:id` - Block user
- `DELETE /block/:id` - Unblock user
- `GET /blocked` - List blocked users

### OAuth (`/api/oauth`)
- `GET /providers` - List OAuth providers
- `GET /:provider` - Start OAuth flow
- `GET /:provider/callback` - OAuth callback
- `POST /:provider/link` - Link OAuth account
- `DELETE /unlink/:provider` - Unlink OAuth account

### Two-Factor Auth (`/api/2fa`)
- `GET /status` - Get 2FA status
- `POST /setup` - Setup 2FA (get QR code)
- `POST /confirm` - Confirm 2FA setup
- `POST /verify` - Verify 2FA code
- `POST /disable` - Disable 2FA
- `POST /backup-codes` - Regenerate backup codes

### GDPR (`/api/gdpr`)
- `GET /info` - Privacy information
- `GET /export` - Export all user data
- `GET /retention` - Data retention policy
- `POST /anonymize` - Anonymize account
- `DELETE /delete` - Delete account

## Project Structure

```
backend/
├── src/
│   ├── config/          # Configuration files
│   ├── controllers/     # Route controllers
│   ├── middleware/      # Custom middleware
│   ├── models/          # Database models
│   ├── routes/          # API routes
│   ├── services/        # Business logic
│   ├── utils/           # Utility functions
│   ├── plugins/         # Fastify plugins
│   └── app.ts           # Main application
├── database/
│   ├── migrations/      # Database migrations
│   └── seeds/           # Seed data
├── tests/               # Test files
├── certs/               # SSL certificates
└── uploads/             # File uploads
```

## Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run lint` - Run ESLint
- `npm run format` - Format code with Prettier
- `npm test` - Run tests
- `npm run db:migrate` - Run database migrations
- `npm run db:seed` - Seed database

## Environment Variables

See `.env.example` for all available configuration options.

## License

MIT
